var app    = require('express')();
var http   = require('http').Server(app);
var io     = require('socket.io')(http);
var fs     = require('fs');

// URL handlers, only this white list of resources are accessible
app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

app.get('/css/main.css', function(req, res){
  res.sendFile(__dirname + '/css/main.css');
});

app.get('/chart-js/Chart.js', function(req, res){
  res.sendFile(__dirname + '/chart-js/Chart.js');
});

app.get('/js/tweets.js', function(req, res){
  res.sendFile(__dirname + '/js/tweets.js');
});

app.get('/js/heatmap.js', function(req, res){
  res.sendFile(__dirname + '/js/heatmap.js');
});

app.get('/js/chart.js', function(req, res){
  res.sendFile(__dirname + '/js/chart.js');
});

// socket.io file watchers
fs.watchFile('./chart.txt', function(curr,prev) {
  console.log("chart.txt changed");
  fs.readFile('chart.txt', function (err,data) {
    if (err) {
      return console.log(err);
    }
    var chart = data.toString();
    io.sockets.emit('chart', chart);
  });
});

fs.watchFile('./heat.txt', function(curr,prev) {
  console.log("heat.txt changed");
  fs.readFile('heat.txt', function (err,data) {
    if (err) {
      return console.log(err);
    }
    var heat = data.toString();
    io.sockets.emit('heat', heat);
  });
});

fs.watchFile('./text.txt', function(curr,prev) {
  console.log("text.txt changed");
  fs.readFile('text.txt', function (err,data) {
    if (err) {
      return console.log(err);
    }
    var text = data.toString();
    io.sockets.emit('text', text);
  });
});

http.listen(8080, function(){
  console.log('listening');
});
