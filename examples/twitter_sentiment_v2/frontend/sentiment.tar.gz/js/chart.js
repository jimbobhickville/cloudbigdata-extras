var ctx, labels, data, options, myRadarChart;

ctx = document.getElementById("myChart").getContext("2d");
options = {
    pointLabelFontSize : 18,
    pointLabelFontColor : "#000",
};

labels = [];

data = {
    datasets: [
        {
            label: "Positive Sentiment",
            fillColor: "rgba(90,170,40,0.2)",
            strokeColor: "rgba(90,170,40,1)",
            pointColor: "rgba(90,170,40,1)",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(90,170,40,1)"
        },
        {
            label: "Negative Sentiment",
            fillColor: "rgba(196,0,34,0.2)",
            strokeColor: "rgba(196,0,34,1)",
            pointColor: "rgba(196,0,34,1)",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(196,0,34,1)"
        }
    ]
};

function initChart() {
    labels = ["", "", "", "", ""];
    data.labels = labels;
    data.datasets[0].data = [0,0,0,0,0];
    data.datasets[1].data = [0,0,0,0,0];

    myRadarChart = new Chart(ctx).Radar(data, options);
}

console.log(myRadarChart);

function rebuildChart(chartData) {
    myRadarChart.destroy();

    data.labels = chartData.labels;
    labels = data.labels;
    data.datasets[0].data = chartData.data[0];
    data.datasets[1].data = chartData.data[1];

    myRadarChart = new Chart(ctx).Radar(data, options);
}

function updateChart(chartData) {
    for (var i = 0, l=chartData.data.length; i < l; i++) {
        for (var a = 0, b=chartData.data[i].length; a < b; a++) {
            myRadarChart.datasets[i].points[a].value = chartData.data[i][a];
        }
    }
        myRadarChart.update();
}

function checkLabels(newLabels) {
    if (labels.length != newLabels.length) {
        return false;
    }

    for (var i = 0, l=labels.length; i < l; i++) {
        if (labels[i] != newLabels[i]) {
            return false;
        }
    }

    return true;
}

function writeChart(chartData) {
    if(!checkLabels(chartData.labels)) {
        rebuildChart(chartData);
    } else {
        updateChart(chartData);
    }
}

initChart();
